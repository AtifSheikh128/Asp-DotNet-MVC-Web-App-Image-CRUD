using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using File_Upload_crud.Models;

namespace File_Upload_crud.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

}
